/*
Gonzalez Nuñez Isai
Zuñiga de Leon Bryan
 */
package Nodos;

import back_end.Pagina;


public class ListaUnidireccional {

    
    public record Resultado(Pagina pagina, int posicion) { }

    private Nodo primero;
    private int tamano;

    public ListaUnidireccional() {
        this.primero = null;
        this.tamano = 0;
    }

    

    public void insertarAlPrincipio(Pagina pagina) {
        Nodo nuevo = new Nodo(pagina);
        nuevo.setSiguiente(primero);
        primero = nuevo;
        tamano++;
    }

    public void insertarAlFinal(Pagina pagina) {
        Nodo nuevo = new Nodo(pagina);
        if (primero == null) {
            primero = nuevo;
        } else {
            Nodo actual = primero;
            while (actual.getSiguiente() != null) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(nuevo);
        }
        tamano++;
    }

    
    public void insertarEnPosicion(Pagina pagina, int posicion) {
        if (posicion < 0 || posicion > tamano) {
            throw new IndexOutOfBoundsException(
                    "Posición inválida: " + posicion + ". Rango permitido: 0 a " + tamano + ".");
        }
        if (posicion == 0) {
            insertarAlPrincipio(pagina);
            return;
        }
        Nodo nuevo = new Nodo(pagina);
        Nodo predecesor = nodoEn(posicion - 1);
        nuevo.setSiguiente(predecesor.getSiguiente());
        predecesor.setSiguiente(nuevo);
        tamano++;
    }

    

    public Pagina removerAlPrincipio() {
        validarNoVacia();
        Nodo removido = primero;
        primero = removido.getSiguiente();
        removido.setSiguiente(null);
        tamano--;
        return removido.getDato();
    }

    public Pagina removerAlFinal() {
        validarNoVacia();
        if (primero.getSiguiente() == null) {
            return removerAlPrincipio();
        }
        Nodo penultimo = primero;
        while (penultimo.getSiguiente().getSiguiente() != null) {
            penultimo = penultimo.getSiguiente();
        }
        Nodo removido = penultimo.getSiguiente();
        penultimo.setSiguiente(null);
        tamano--;
        return removido.getDato();
    }

    public Pagina removerEnPosicion(int posicion) {
        validarNoVacia();
        validarPosicion(posicion);
        if (posicion == 0) {
            return removerAlPrincipio();
        }
        Nodo anterior = nodoEn(posicion - 1);
        Nodo removido = anterior.getSiguiente();
        anterior.setSiguiente(removido.getSiguiente());
        removido.setSiguiente(null);
        tamano--;
        return removido.getDato();
    }

    

    public Pagina mostrarAlPrincipio() {
        validarNoVacia();
        return primero.getDato();
    }

    public Pagina mostrarAlFinal() {
        validarNoVacia();
        Nodo actual = primero;
        while (actual.getSiguiente() != null) {
            actual = actual.getSiguiente();
        }
        return actual.getDato();
    }

    public Pagina mostrarEnPosicion(int posicion) {
        validarNoVacia();
        validarPosicion(posicion);
        return nodoEn(posicion).getDato();
    }

    

    /** Busca por valor clave (la URL, sin distinguir mayúsculas). Retorna null si no existe. */
    public Resultado buscarPorValor(String url) {
        if (url == null) {
            return null;
        }
        String clave = url.trim();
        Nodo actual = primero;
        int indice = 0;
        while (actual != null) {
            if (actual.getDato().url().equalsIgnoreCase(clave)) {
                return new Resultado(actual.getDato(), indice);
            }
            actual = actual.getSiguiente();
            indice++;
        }
        return null;
    }

    

    public void vaciar() {
        primero = null;
        tamano = 0;
    }

    public boolean estaVacia() {
        return primero == null;
    }

    public int obtenerTamano() {
        return tamano;
    }

    public Nodo getPrimero() {
        return primero;
    }

    

    private void validarNoVacia() {
        if (estaVacia()) {
            throw new IllegalStateException("La lista está vacía.");
        }
    }

    private void validarPosicion(int posicion) {
        if (posicion < 0 || posicion >= tamano) {
            throw new IndexOutOfBoundsException(
                    "Posición inválida: " + posicion + ". Rango permitido: 0 a " + (tamano - 1) + ".");
        }
    }

    private Nodo nodoEn(int posicion) {
        Nodo actual = primero;
        for (int i = 0; i < posicion; i++) {
            actual = actual.getSiguiente();
        }
        return actual;
    }
}
